import { Shield, FileText, ArrowLeft } from 'lucide-react'
import { Button } from '../ui/button'

interface HeaderProps {
  onBackToLanding: () => void
}

const Header = ({ onBackToLanding }: HeaderProps) => {
  console.log('Rendering enhanced Header component with dark mode')
  
  return (
    <header className="bg-gray-900/95 backdrop-blur-sm shadow-lg border-b border-gray-700">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-600 rounded-xl">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                PharmaCompliance Pro
              </h1>
              <p className="text-sm text-blue-200">
                AI-Enhanced USFDA SOP Compliance Review Platform
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-blue-200">
              <FileText className="w-4 h-4" />
              <span>21 CFR Part 211 Compliant</span>
            </div>
            
            <Button
              onClick={onBackToLanding}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header