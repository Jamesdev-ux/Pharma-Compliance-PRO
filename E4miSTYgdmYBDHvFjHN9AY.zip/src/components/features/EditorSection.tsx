import { useState } from 'react'
import { Save, ArrowLeft, AlertTriangle, CheckCircle, Brain, Lightbulb, Copy } from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Textarea } from '../ui/textarea'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { toast } from 'sonner'
import type { SOPDocument, ComplianceReport } from '../../types/sop'

interface EditorSectionProps {
  document: SOPDocument
  report: ComplianceReport | null
  onSave: (document: SOPDocument) => void
  onBackToReport: () => void
}

const EditorSection = ({ document, report, onSave, onBackToReport }: EditorSectionProps) => {
  const [content, setContent] = useState(document.content)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)

  console.log('Rendering enhanced EditorSection for document:', document.name)

  const handleContentChange = (newContent: string) => {
    setContent(newContent)
    setHasUnsavedChanges(newContent !== document.content)
  }

  const handleSave = () => {
    console.log('Saving document changes with AI recommendations applied...')
    const updatedDocument: SOPDocument = {
      ...document,
      content,
      uploadDate: new Date().toISOString()
    }
    
    onSave(updatedDocument)
    setHasUnsavedChanges(false)
    toast.success('Document saved successfully with AI improvements')
  }

  const handleApplyProposedChange = (originalText: string, proposedText: string) => {
    const updatedContent = content.replace(originalText, proposedText)
    setContent(updatedContent)
    setHasUnsavedChanges(true)
    toast.success('Proposed change applied to document')
  }

  const handleCopyProposedText = (proposedText: string) => {
    navigator.clipboard.writeText(proposedText)
    toast.success('Proposed text copied to clipboard')
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'compliant':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'non-compliant':
        return <AlertTriangle className="w-4 h-4 text-red-600" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'compliant':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'non-compliant':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-pharma-gray mb-2 flex items-center space-x-2">
            <Brain className="w-8 h-8 text-pharma-blue" />
            <span>AI-Guided SOP Editor</span>
          </h2>
          <p className="text-lg text-pharma-gray-medium">
            Edit your document with AI-powered compliance recommendations
          </p>
        </div>
        <Button
          onClick={onBackToReport}
          variant="outline"
          className="border-pharma-gray-light text-pharma-gray-medium"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Report
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Editor */}
        <div className="lg:col-span-2">
          <Card className="pharma-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{document.name}</span>
                <div className="flex items-center space-x-2">
                  {hasUnsavedChanges && (
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                      Unsaved Changes
                    </Badge>
                  )}
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                    AI-Enhanced
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={content}
                onChange={(e) => handleContentChange(e.target.value)}
                className="min-h-[600px] font-mono text-sm resize-y"
                placeholder="Edit your SOP content here with AI guidance..."
              />
              <div className="flex justify-end mt-4">
                <Button
                  onClick={handleSave}
                  disabled={!hasUnsavedChanges}
                  className="pharma-button-primary"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save AI-Enhanced Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Compliance Guidance */}
        <div>
          <Card className="pharma-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-pharma-blue" />
                <span>AI Compliance Assistant</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="proposed-changes" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="proposed-changes">Changes</TabsTrigger>
                  <TabsTrigger value="issues">Issues</TabsTrigger>
                  <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
                </TabsList>
                
                <TabsContent value="proposed-changes" className="space-y-4">
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {report?.sections.map((section) => 
                      section.proposedChanges.map((change, changeIndex) => (
                        <div key={`${section.id}-${changeIndex}`} className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <h5 className="font-medium text-sm text-pharma-gray">{section.title}</h5>
                            <Badge className={getPriorityColor(change.priority)} variant="outline">
                              {change.priority.toUpperCase()}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div>
                              <h6 className="text-xs font-medium text-red-600 mb-1">Current:</h6>
                              <p className="text-xs text-pharma-gray-medium bg-red-50 p-2 rounded border-l-2 border-red-200">
                                "{change.originalText}"
                              </p>
                            </div>
                            <div>
                              <h6 className="text-xs font-medium text-green-600 mb-1">Proposed:</h6>
                              <p className="text-xs text-pharma-gray-medium bg-green-50 p-2 rounded border-l-2 border-green-200">
                                "{change.proposedText}"
                              </p>
                            </div>
                          </div>
                          
                          <div>
                            <h6 className="text-xs font-medium text-pharma-gray mb-1">Reason:</h6>
                            <p className="text-xs text-pharma-gray-medium">{change.reason}</p>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleApplyProposedChange(change.originalText, change.proposedText)}
                              className="text-xs"
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Apply
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCopyProposedText(change.proposedText)}
                              className="text-xs"
                            >
                              <Copy className="w-3 h-3 mr-1" />
                              Copy
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="issues" className="space-y-4">
                  {report?.sections.map((section) => (
                    <div key={section.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">{section.title}</h4>
                        <Badge className={getStatusColor(section.complianceStatus)} variant="outline">
                          {getStatusIcon(section.complianceStatus)}
                        </Badge>
                      </div>
                      <p className="text-xs text-pharma-gray-medium mb-3">
                        {section.content}
                      </p>
                      
                      {section.llmAnalysis && (
                        <div className="bg-blue-50 rounded p-2 mb-3">
                          <div className="flex items-center space-x-1 mb-1">
                            <Brain className="w-3 h-3 text-pharma-blue" />
                            <span className="text-xs font-medium text-pharma-blue">AI Analysis:</span>
                          </div>
                          <p className="text-xs text-pharma-gray-medium">{section.llmAnalysis}</p>
                        </div>
                      )}
                      
                      {section.recommendations.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-pharma-gray mb-1">Recommendations:</p>
                          <ul className="space-y-1">
                            {section.recommendations.map((rec, index) => (
                              <li key={index} className="text-xs text-pharma-gray-medium flex items-start space-x-1">
                                <span className="text-pharma-blue mt-0.5">•</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </TabsContent>
                
                <TabsContent value="guidelines" className="space-y-4">
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-2 flex items-center space-x-1">
                        <Lightbulb className="w-4 h-4 text-pharma-blue" />
                        <span>AI Best Practices</span>
                      </h4>
                      <ul className="text-xs text-pharma-gray-medium space-y-1">
                        <li>• Use specific, measurable language for procedures</li>
                        <li>• Reference regulatory sections explicitly</li>
                        <li>• Include qualification requirements for personnel</li>
                        <li>• Specify data integrity controls (ALCOA+)</li>
                      </ul>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-2">Document Structure</h4>
                      <ul className="text-xs text-pharma-gray-medium space-y-1">
                        <li>• Clear purpose and scope statement</li>
                        <li>• Defined roles and responsibilities</li>
                        <li>• Step-by-step procedures</li>
                        <li>• Reference to applicable regulations</li>
                      </ul>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-2">Data Integrity</h4>
                      <ul className="text-xs text-pharma-gray-medium space-y-1">
                        <li>• ALCOA+ principles compliance</li>
                        <li>• Electronic signature requirements</li>
                        <li>• Audit trail specifications</li>
                        <li>• Data backup and recovery</li>
                      </ul>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-2">Quality Requirements</h4>
                      <ul className="text-xs text-pharma-gray-medium space-y-1">
                        <li>• Change control procedures</li>
                        <li>• Training documentation</li>
                        <li>• Periodic review requirements</li>
                        <li>• Deviation handling process</li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default EditorSection