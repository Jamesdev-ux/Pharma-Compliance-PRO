import { useState, useEffect } from 'react'
import { FileText, Clock, CheckCircle, Play, Brain } from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Progress } from '../ui/progress'
import type { SOPDocument, AnalysisProgress } from '../../types/sop'

interface AnalysisSectionProps {
  document: SOPDocument
  isAnalyzing: boolean
  onStartAnalysis: () => void
  onViewReport: () => void
  hasReport: boolean
}

const AnalysisSection = ({ 
  document, 
  isAnalyzing, 
  onStartAnalysis, 
  onViewReport, 
  hasReport 
}: AnalysisSectionProps) => {
  const [progress, setProgress] = useState<AnalysisProgress>({
    stage: 'Initializing',
    progress: 0,
    message: 'Preparing document analysis...'
  })

  console.log('Rendering AnalysisSection, isAnalyzing:', isAnalyzing, 'hasReport:', hasReport)

  useEffect(() => {
    if (!isAnalyzing) return

    console.log('Starting enhanced analysis with LLM integration...')
    const stages = [
      { stage: 'Document Processing', progress: 15, message: 'Extracting and parsing SOP content...' },
      { stage: 'LLM Pre-Analysis', progress: 30, message: 'AI analyzing document structure and content...' },
      { stage: 'Regulatory Mapping', progress: 45, message: 'Cross-referencing with USFDA guidelines...' },
      { stage: 'Compliance Analysis', progress: 65, message: 'Identifying compliance gaps and issues...' },
      { stage: 'LLM Recommendations', progress: 80, message: 'Generating AI-powered improvement suggestions...' },
      { stage: 'Report Generation', progress: 95, message: 'Creating detailed compliance report...' },
      { stage: 'Complete', progress: 100, message: 'Analysis complete! Enhanced report ready for review.' }
    ]

    let currentStage = 0
    const interval = setInterval(() => {
      if (currentStage < stages.length) {
        console.log('Analysis progress:', stages[currentStage])
        setProgress(stages[currentStage])
        currentStage++
      } else {
        clearInterval(interval)
      }
    }, 500)

    return () => clearInterval(interval)
  }, [isAnalyzing])

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-pharma-gray mb-4">
          AI-Enhanced SOP Compliance Analysis
        </h2>
        <p className="text-lg text-pharma-gray-medium">
          Review your document details and start the AI-powered compliance analysis
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="pharma-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-pharma-blue" />
              <span>Document Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-pharma-gray-medium">Document Name</label>
              <p className="text-pharma-gray font-medium">{document.name}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-pharma-gray-medium">File Size</label>
              <p className="text-pharma-gray">{formatFileSize(document.fileSize)}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-pharma-gray-medium">Upload Date</label>
              <p className="text-pharma-gray">
                {new Date(document.uploadDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-pharma-gray-medium">Content Preview</label>
              <div className="bg-gray-50 rounded-lg p-4 max-h-32 overflow-y-auto">
                <p className="text-sm text-pharma-gray">
                  {document.content.substring(0, 200)}
                  {document.content.length > 200 && '...'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="pharma-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              {isAnalyzing ? (
                <Clock className="w-5 h-5 text-pharma-blue animate-spin" />
              ) : hasReport ? (
                <CheckCircle className="w-5 h-5 text-pharma-green" />
              ) : (
                <Brain className="w-5 h-5 text-pharma-blue" />
              )}
              <span>
                {isAnalyzing ? 'AI Analysis in Progress' : hasReport ? 'Analysis Complete' : 'Ready for AI Analysis'}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {!isAnalyzing && !hasReport && (
              <div className="text-center">
                <p className="text-pharma-gray-medium mb-6">
                  Click the button below to start the AI-enhanced USFDA compliance analysis with detailed improvement recommendations.
                </p>
                <Button 
                  onClick={onStartAnalysis}
                  className="pharma-button-primary"
                  size="lg"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Start AI Compliance Analysis
                </Button>
              </div>
            )}

            {isAnalyzing && (
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm font-medium text-pharma-gray mb-2">
                    <span>{progress.stage}</span>
                    <span>{progress.progress}%</span>
                  </div>
                  <Progress value={progress.progress} className="h-2" />
                </div>
                <p className="text-sm text-pharma-gray-medium">{progress.message}</p>
                {progress.stage === 'LLM Pre-Analysis' && (
                  <div className="flex items-center space-x-2 text-xs text-pharma-blue">
                    <Brain className="w-3 h-3" />
                    <span>AI analyzing document patterns and structure...</span>
                  </div>
                )}
                {progress.stage === 'LLM Recommendations' && (
                  <div className="flex items-center space-x-2 text-xs text-pharma-blue">
                    <Brain className="w-3 h-3" />
                    <span>Generating intelligent improvement suggestions...</span>
                  </div>
                )}
              </div>
            )}

            {hasReport && !isAnalyzing && (
              <div className="text-center">
                <div className="mb-4">
                  <CheckCircle className="w-16 h-16 text-pharma-green mx-auto mb-2" />
                  <p className="text-pharma-gray font-medium">
                    AI-enhanced compliance analysis completed successfully!
                  </p>
                </div>
                <Button 
                  onClick={onViewReport}
                  className="pharma-button-primary"
                  size="lg"
                >
                  View Enhanced Compliance Report
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="pharma-card mt-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5 text-pharma-blue" />
            <span>AI-Enhanced Analysis Coverage</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg border-l-4 border-pharma-blue">
              <h4 className="font-semibold text-pharma-gray mb-2">Smart Document Review</h4>
              <p className="text-sm text-pharma-gray-medium">
                AI analyzes structure, clarity, and regulatory compliance with specific improvement suggestions
              </p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg border-l-4 border-pharma-green">
              <h4 className="font-semibold text-pharma-gray mb-2">Regulatory Intelligence</h4>
              <p className="text-sm text-pharma-gray-medium">
                Cross-references 21 CFR Part 211 with AI-powered interpretation and context analysis
              </p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg border-l-4 border-purple-500">
              <h4 className="font-semibold text-pharma-gray mb-2">Proposed Changes</h4>
              <p className="text-sm text-pharma-gray-medium">
                Specific text modifications with before/after comparisons and implementation priority
              </p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg border-l-4 border-orange-500">
              <h4 className="font-semibold text-pharma-gray mb-2">Quality Enhancement</h4>
              <p className="text-sm text-pharma-gray-medium">
                AI recommendations for training, change control, and documentation best practices
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AnalysisSection