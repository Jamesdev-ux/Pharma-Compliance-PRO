import { useState, useRef } from 'react'
import { Upload, FileText, Clipboard, Shield } from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardContent } from '../ui/card'
import { Textarea } from '../ui/textarea'
import { toast } from 'sonner'
import type { SOPDocument } from '../../types/sop'

interface UploadSectionProps {
  onDocumentUpload: (document: SOPDocument) => void
}

const UploadSection = ({ onDocumentUpload }: UploadSectionProps) => {
  const [dragActive, setDragActive] = useState(false)
  const [pastedContent, setPastedContent] = useState('')
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload')
  const fileInputRef = useRef<HTMLInputElement>(null)

  console.log('Rendering enhanced UploadSection with dark mode, active tab:', activeTab)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const files = Array.from(e.dataTransfer.files)
    console.log('Files dropped:', files.length)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleFileSelect = async (file: File) => {
    console.log('Processing file:', file.name, 'Type:', file.type, 'Size:', file.size)
    
    if (!file.type.match(/(text\/plain|application\/pdf|application\/msword|application\/vnd.openxmlformats-officedocument.wordprocessingml.document)/)) {
      toast.error('Please upload a text, PDF, or Word document')
      return
    }

    try {
      let content = ''
      if (file.type === 'text/plain') {
        content = await file.text()
      } else {
        // For demo purposes, we'll use the filename as content for non-text files
        content = `[${file.type}] Document content will be extracted here.\n\nFilename: ${file.name}\nSize: ${(file.size / 1024).toFixed(2)} KB`
      }

      const sopDocument: SOPDocument = {
        id: Date.now().toString(),
        name: file.name,
        content,
        uploadDate: new Date().toISOString(),
        fileSize: file.size,
        fileType: file.type
      }

      console.log('Created SOP document:', sopDocument.id)
      toast.success('Document uploaded successfully')
      onDocumentUpload(sopDocument)
    } catch (error) {
      console.error('Error processing file:', error)
      toast.error('Error processing file')
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handlePastedContentSubmit = () => {
    if (!pastedContent.trim()) {
      toast.error('Please paste your SOP content')
      return
    }

    console.log('Processing pasted content, length:', pastedContent.length)
    
    const sopDocument: SOPDocument = {
      id: Date.now().toString(),
      name: `Pasted SOP - ${new Date().toLocaleDateString()}`,
      content: pastedContent,
      uploadDate: new Date().toISOString(),
      fileSize: new Blob([pastedContent]).size,
      fileType: 'text/plain'
    }

    console.log('Created SOP document from paste:', sopDocument.id)
    toast.success('SOP content processed successfully')
    onDocumentUpload(sopDocument)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">
          AI-Enhanced USFDA SOP Compliance Review
        </h2>
        <p className="text-lg text-blue-200 max-w-2xl mx-auto">
          Upload your Standard Operating Procedure documents or paste content directly. 
          Our AI will analyze compliance with 21 CFR Part 211 and highlight specific sections needing improvement.
        </p>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-8">
          <div className="flex border-b border-gray-600 mb-6">
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-6 py-3 font-medium transition-colors ${
                activeTab === 'upload'
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Upload Document
            </button>
            <button
              onClick={() => setActiveTab('paste')}
              className={`px-6 py-3 font-medium transition-colors ${
                activeTab === 'paste'
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Paste Content
            </button>
          </div>

          {activeTab === 'upload' && (
            <div
              className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
                dragActive
                  ? 'border-blue-400 bg-blue-900/20'
                  : 'border-gray-600 hover:border-blue-400'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                Drop your SOP document here
              </h3>
              <p className="text-gray-400 mb-6">
                Supports PDF, Word documents, and text files up to 10MB
              </p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <FileText className="w-4 h-4 mr-2" />
                Choose File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,.pdf,.doc,.docx"
                onChange={handleFileInput}
                className="hidden"
              />
            </div>
          )}

          {activeTab === 'paste' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-white mb-4">
                <Clipboard className="w-5 h-5" />
                <span className="font-medium">Paste your SOP content below:</span>
              </div>
              <Textarea
                value={pastedContent}
                onChange={(e) => setPastedContent(e.target.value)}
                placeholder="Paste your Standard Operating Procedure content here..."
                className="min-h-[300px] resize-y bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
              <div className="flex justify-end">
                <Button
                  onClick={handlePastedContentSubmit}
                  disabled={!pastedContent.trim()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Analyze Content
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="mt-8 grid md:grid-cols-3 gap-6">
        <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-white">Section-Level Analysis</h3>
            </div>
            <p className="text-sm text-gray-300">
              AI identifies specific sections (e.g., 5.1.2, 7.3.1) that require compliance improvements with precise regulatory references.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-white">Proposed Text Changes</h3>
            </div>
            <p className="text-sm text-gray-300">
              Get specific before/after text modifications with implementation priority and regulatory justification.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                <Upload className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-white">Interactive Editor</h3>
            </div>
            <p className="text-sm text-gray-300">
              Built-in editor with one-click application of AI-recommended changes and real-time compliance guidance.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default UploadSection