import { useState } from 'react'
import { ArrowRight, Shield, FileText, Brain, CheckCircle, Star, MessageSquare } from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Textarea } from '../ui/textarea'
import { Input } from '../ui/input'
import { toast } from 'sonner'

interface LandingPageProps {
  onGetStarted: () => void
}

const LandingPage = ({ onGetStarted }: LandingPageProps) => {
  const [feedback, setFeedback] = useState('')
  const [userEmail, setUserEmail] = useState('')
  const [rating, setRating] = useState(0)

  console.log('Rendering LandingPage component')

  const handleFeedbackSubmit = () => {
    if (!feedback.trim()) {
      toast.error('Please provide your feedback')
      return
    }

    console.log('Feedback submitted:', { feedback, userEmail, rating })
    toast.success('Thank you for your feedback! We appreciate your input.')
    setFeedback('')
    setUserEmail('')
    setRating(0)
  }

  const handleRatingClick = (selectedRating: number) => {
    setRating(selectedRating)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 text-white">
      {/* Hero Section */}
      <section className="relative py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center justify-center w-20 h-20 bg-blue-600 rounded-2xl mr-4">
              <Shield className="w-12 h-12 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-5xl font-bold mb-2">
                PharmaCompliance Pro
              </h1>
              <p className="text-xl text-blue-200">
                AI-Powered USFDA SOP Compliance Review Platform
              </p>
            </div>
          </div>
          
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-12">
            Transform your pharmaceutical Standard Operating Procedures with intelligent AI analysis. 
            Get instant compliance insights, detailed recommendations, and regulatory alignment with 21 CFR Part 211.
          </p>
          
          <Button 
            onClick={onGetStarted}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg rounded-xl"
            size="lg"
          >
            Start Compliance Review
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-gray-800/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            AI-Enhanced Compliance Capabilities
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <Brain className="w-6 h-6 text-blue-400" />
                  <span>Intelligent SOP Analysis</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>Advanced AI analyzes document structure, regulatory language, and compliance gaps with section-specific recommendations and proposed text changes.</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <Shield className="w-6 h-6 text-green-400" />
                  <span>21 CFR Part 211 Compliance</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>Comprehensive cross-referencing with USFDA regulations including data integrity, personnel qualifications, and change control requirements.</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <FileText className="w-6 h-6 text-purple-400" />
                  <span>Section-Level Identification</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>Precise identification of non-compliant sections (e.g., 5.1.2, 7.3.1) with detailed before/after text proposals and regulatory justifications.</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <CheckCircle className="w-6 h-6 text-orange-400" />
                  <span>Proposed Text Changes</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>AI-generated specific text replacements with priority levels, implementation reasons, and one-click application in the integrated editor.</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <Brain className="w-6 h-6 text-cyan-400" />
                  <span>Interactive SOP Editor</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>Built-in editor with AI guidance, real-time compliance suggestions, and seamless integration of proposed improvements.</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-white">
                  <FileText className="w-6 h-6 text-red-400" />
                  <span>Comprehensive Reports</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300">
                <p>Detailed PDF reports with compliance scores, critical improvement areas, regulatory references, and actionable recommendations.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            How It Works
          </h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Upload SOP</h3>
              <p className="text-gray-400">Upload your SOP document or paste content directly into the platform</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Analysis</h3>
              <p className="text-gray-400">Our AI analyzes compliance with 21 CFR Part 211 and identifies specific sections needing improvement</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Review Report</h3>
              <p className="text-gray-400">Get detailed compliance report with section numbers, proposed changes, and regulatory references</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">4</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Implement Changes</h3>
              <p className="text-gray-400">Use the integrated editor to apply AI-recommended improvements and ensure compliance</p>
            </div>
          </div>
        </div>
      </section>

      {/* Feedback Section */}
      <section className="py-16 bg-gray-800/50">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-white text-center justify-center">
                <MessageSquare className="w-6 h-6 text-blue-400" />
                <span>Share Your Feedback</span>
              </CardTitle>
              <p className="text-gray-400 text-center">
                Help us improve PharmaCompliance Pro with your valuable feedback
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Rate your experience
                </label>
                <div className="flex space-x-2 justify-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => handleRatingClick(star)}
                      className={`p-1 transition-colors ${
                        star <= rating ? 'text-yellow-400' : 'text-gray-600'
                      }`}
                    >
                      <Star className="w-8 h-8 fill-current" />
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Your feedback
                </label>
                <Textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Tell us about your experience, suggest improvements, or report any issues..."
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 min-h-[120px]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Email (optional)
                </label>
                <Input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="your.email@company.com"
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                />
              </div>
              
              <Button
                onClick={handleFeedbackSubmit}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                Submit Feedback
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 border-t border-gray-800">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            © 2024 PharmaCompliance Pro - Powered by OnSpace.AI | 
            Professional pharmaceutical compliance solutions
          </p>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage