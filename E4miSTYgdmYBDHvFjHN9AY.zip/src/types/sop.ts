export interface SOPDocument {
  id: string
  name: string
  content: string
  uploadDate: string
  fileSize: number
  fileType: string
}

export interface ProposedChange {
  originalText: string
  proposedText: string
  reason: string
  priority: 'high' | 'medium' | 'low'
  sectionNumber?: string
}

export interface ComplianceSection {
  id: string
  title: string
  content: string
  complianceStatus: 'compliant' | 'non-compliant' | 'needs-review'
  recommendations: string[]
  proposedChanges: ProposedChange[]
  regulatoryReferences: string[]
  llmAnalysis?: string
  improvementSections: string[]
  sectionNumbers?: string[]
}

export interface ComplianceReport {
  id: string
  documentId: string
  documentName: string
  analysisDate: string
  overallCompliance: 'compliant' | 'non-compliant' | 'needs-review'
  complianceScore: number
  sections: ComplianceSection[]
  summary: string
  llmRecommendations: string[]
  criticalImprovements: string[]
}

export interface AnalysisProgress {
  stage: string
  progress: number
  message: string
}