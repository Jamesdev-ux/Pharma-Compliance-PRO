import { useState } from 'react'
import { Toaster } from './components/ui/sonner'
import Header from './components/layout/Header'
import LandingPage from './components/features/LandingPage'
import UploadSection from './components/features/UploadSection'
import AnalysisSection from './components/features/AnalysisSection'
import ReportSection from './components/features/ReportSection'
import EditorSection from './components/features/EditorSection'
import type { SOPDocument, ComplianceReport, ProposedChange } from './types/sop'

console.log('App component initializing with enhanced dark mode and section highlighting...')

function App() {
  const [currentSection, setCurrentSection] = useState<'landing' | 'upload' | 'analysis' | 'report' | 'editor'>('landing')
  const [sopDocument, setSOPDocument] = useState<SOPDocument | null>(null)
  const [complianceReport, setComplianceReport] = useState<ComplianceReport | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  console.log('Current section:', currentSection)
  console.log('SOP document exists:', !!sopDocument)
  console.log('Compliance report exists:', !!complianceReport)

  const handleGetStarted = () => {
    console.log('User clicked Get Started, navigating to upload section')
    setCurrentSection('upload')
  }

  const handleDocumentUpload = (document: SOPDocument) => {
    console.log('Document uploaded:', document.name)
    setSOPDocument(document)
    setCurrentSection('analysis')
  }

  const generateLLMAnalysis = (content: string) => {
    // Enhanced LLM analysis with section-specific insights
    const analysisPoints = [
      'Section 5.1.2 lacks specific personnel qualification requirements and training verification procedures',
      'Section 7.3.1 data integrity controls need enhancement for ALCOA+ compliance with electronic signature requirements',
      'Section 3.2.4 change control procedures should reference risk assessment and stakeholder approval workflows',
      'Section 6.1.3 equipment cleaning validation lacks specific acceptance criteria and verification methods',
      'Section 4.5.1 document revision history requires enhanced tracking with regulatory impact assessment'
    ]
    
    return analysisPoints[Math.floor(Math.random() * analysisPoints.length)]
  }

  const generateProposedChanges = (sectionTitle: string): ProposedChange[] => {
    const changeExamples = {
      'Document Structure': [
        {
          originalText: 'This procedure describes the cleaning process.',
          proposedText: 'This Standard Operating Procedure (SOP-CLEAN-001) defines the validated cleaning procedures for pharmaceutical manufacturing equipment in accordance with 21 CFR 211.67 and Section 5.1.2 of the Quality Manual.',
          reason: 'Section 1.1.1 requires specific SOP numbering, regulatory reference, and quality manual cross-reference',
          priority: 'high' as const,
          sectionNumber: '1.1.1'
        }
      ],
      'Roles and Responsibilities': [
        {
          originalText: 'Operators should follow the procedure.',
          proposedText: 'Section 5.1.2: Qualified operators, trained per SOP-TR-001 and with current GMP certification Level II, shall execute this procedure under direct supervision of a Production Supervisor (minimum 2 years experience).',
          reason: 'Section 5.1.2 compliance requires specific qualification matrix, training references, and supervision hierarchy',
          priority: 'high' as const,
          sectionNumber: '5.1.2'
        }
      ],
      'Data Integrity': [
        {
          originalText: 'Record all data in the logbook.',
          proposedText: 'Section 7.3.1: Record all data contemporaneously in the designated controlled logbook using permanent ink, with any corrections initialed, dated, and justified per ALCOA+ principles (21 CFR 211.194).',
          reason: 'Section 7.3.1 data integrity requirements per FDA guidance on ALCOA+ principles and electronic records',
          priority: 'medium' as const,
          sectionNumber: '7.3.1'
        }
      ]
    }
    
    return changeExamples[sectionTitle as keyof typeof changeExamples] || []
  }

  const handleAnalysisStart = () => {
    console.log('Starting enhanced compliance analysis with section-specific LLM integration...')
    setIsAnalyzing(true)
    setCurrentSection('analysis')
    
    // Enhanced analysis process with section highlighting
    setTimeout(() => {
      console.log('Analysis completed, generating enhanced report with section numbers...')
      const mockReport: ComplianceReport = {
        id: Date.now().toString(),
        documentId: sopDocument?.id || '',
        documentName: sopDocument?.name || '',
        analysisDate: new Date().toISOString(),
        overallCompliance: 'non-compliant',
        complianceScore: 68,
        llmRecommendations: [
          'Section 5.1.2: Implement comprehensive personnel qualification matrix with specific training requirements',
          'Section 7.3.1: Add detailed data integrity controls with electronic signature and audit trail requirements',
          'Section 3.2.4: Enhance change control procedures with risk assessment and multi-level approval workflows',
          'Section 6.1.3: Include equipment validation protocols with specific acceptance criteria and verification methods'
        ],
        criticalImprovements: [
          'Section 5.1.2 - Personnel Qualification Requirements',
          'Section 7.3.1 - Data Integrity Implementation', 
          'Section 3.2.4 - Change Control Integration',
          'Section 6.1.3 - Equipment Validation Protocols'
        ],
        sections: [
          {
            id: '1',
            title: 'Document Structure',
            content: 'Section 1.1.1 purpose statement lacks regulatory alignment and specific manufacturing context',
            complianceStatus: 'non-compliant',
            recommendations: [
              'Section 1.1.1: Add detailed purpose statement referencing specific manufacturing operations and regulatory basis',
              'Section 1.2.1: Include scope limitations, applicability criteria, and related SOPs cross-references',
              'Section 1.3.1: Implement hierarchical section numbering consistent with pharmaceutical industry standards'
            ],
            proposedChanges: generateProposedChanges('Document Structure'),
            regulatoryReferences: ['21 CFR 211.100(a)', '21 CFR 211.186(a)', 'ICH Q7 Section 5.4'],
            llmAnalysis: 'AI analysis indicates Section 1.1.1 requires enhanced regulatory language and specific process context for pharmaceutical manufacturing compliance',
            improvementSections: ['Section 1.1.1 - Purpose Statement', 'Section 1.2.1 - Scope Definition', 'Section 1.3.1 - Document Structure'],
            sectionNumbers: ['1.1.1', '1.2.1', '1.3.1']
          },
          {
            id: '2',
            title: 'Roles and Responsibilities',
            content: 'Section 5.1.2 personnel qualifications and supervision requirements not adequately specified',
            complianceStatus: 'non-compliant',
            recommendations: [
              'Section 5.1.2: Define minimum training requirements and competency assessments for each role',
              'Section 5.2.1: Specify supervision requirements for critical manufacturing operations',
              'Section 5.3.1: Include backup personnel assignments and escalation procedures',
              'Section 5.4.1: Add qualification maintenance and retraining schedules'
            ],
            proposedChanges: generateProposedChanges('Roles and Responsibilities'),
            regulatoryReferences: ['21 CFR 211.25(a)', '21 CFR 211.25(b)', '21 CFR 211.28'],
            llmAnalysis: 'Section 5.1.2 analysis indicates insufficient detail in personnel qualification matrix and lack of competency verification procedures',
            improvementSections: ['Section 5.1.2 - Training Requirements', 'Section 5.2.1 - Supervision Structure', 'Section 5.3.1 - Qualification Matrix'],
            sectionNumbers: ['5.1.2', '5.2.1', '5.3.1', '5.4.1']
          },
          {
            id: '3',
            title: 'Data Integrity',
            content: 'Section 7.3.1 basic record retention mentioned but lacks comprehensive ALCOA+ implementation',
            complianceStatus: 'needs-review',
            recommendations: [
              'Section 7.3.1: Implement comprehensive ALCOA+ controls with electronic signature requirements',
              'Section 7.3.2: Add audit trail specifications and data backup procedures',
              'Section 7.3.3: Include long-term retention and data recovery protocols'
            ],
            proposedChanges: generateProposedChanges('Data Integrity'),
            regulatoryReferences: ['21 CFR 211.188', '21 CFR 211.194', 'FDA Data Integrity Guidance'],
            llmAnalysis: 'Section 7.3.1 current data handling procedures need enhancement to meet modern FDA expectations for data integrity and electronic records management',
            improvementSections: ['Section 7.3.1 - ALCOA+ Implementation', 'Section 7.3.2 - Electronic Records', 'Section 7.3.3 - Audit Trails'],
            sectionNumbers: ['7.3.1', '7.3.2', '7.3.3']
          },
          {
            id: '4',
            title: 'Change Control Integration',
            content: 'Section 3.2.4 lacks reference to change control procedures for SOP modifications',
            complianceStatus: 'non-compliant',
            recommendations: [
              'Section 3.2.4: Add comprehensive change control procedures referencing master change control SOP',
              'Section 3.2.5: Include impact assessment requirements for SOP modifications',
              'Section 3.2.6: Specify approval workflows and implementation timelines',
              'Section 3.2.7: Add training update requirements for procedure changes'
            ],
            proposedChanges: [
              {
                originalText: 'This SOP may be updated as needed.',
                proposedText: 'Section 3.2.4: All changes to this SOP shall be processed through the Change Control System (SOP-QA-003) with risk assessment, stakeholder review, and training impact evaluation prior to implementation.',
                reason: 'Section 3.2.4 formal change control integration required for pharmaceutical operations per 21 CFR 211.100(a)',
                priority: 'high' as const,
                sectionNumber: '3.2.4'
              }
            ],
            regulatoryReferences: ['21 CFR 211.100(a)', 'ICH Q7 Section 2.5', 'ICH Q10'],
            llmAnalysis: 'Section 3.2.4 change control integration is critical for maintaining SOP effectiveness and regulatory compliance with pharmaceutical quality systems',
            improvementSections: ['Section 3.2.4 - Change Control Process', 'Section 3.2.5 - Impact Assessment', 'Section 3.2.6 - Training Updates'],
            sectionNumbers: ['3.2.4', '3.2.5', '3.2.6', '3.2.7']
          }
        ],
        summary: 'The SOP requires significant enhancements to meet current USFDA compliance standards. AI analysis identifies critical gaps in sections 5.1.2, 7.3.1, 3.2.4, and 6.1.3. Recommended improvements focus on regulatory alignment, process clarity, and robust quality system integration with specific section-level modifications.'
      }
      
      setComplianceReport(mockReport)
      setIsAnalyzing(false)
      setCurrentSection('report')
    }, 3500)
  }

  const handleViewReport = () => {
    console.log('Navigating to enhanced report view with section highlighting...')
    setCurrentSection('report')
  }

  const handleEditSOP = () => {
    console.log('Opening SOP editor with AI recommendations and section highlighting...')
    setCurrentSection('editor')
  }

  const handleBackToUpload = () => {
    console.log('Returning to upload section...')
    setCurrentSection('upload')
    setSOPDocument(null)
    setComplianceReport(null)
  }

  const handleBackToLanding = () => {
    console.log('Returning to landing page...')
    setCurrentSection('landing')
    setSOPDocument(null)
    setComplianceReport(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 text-white">
      {currentSection !== 'landing' && <Header onBackToLanding={handleBackToLanding} />}
      
      <main className={currentSection === 'landing' ? '' : 'container mx-auto px-4 py-8'}>
        {currentSection === 'landing' && (
          <LandingPage onGetStarted={handleGetStarted} />
        )}
        
        {currentSection === 'upload' && (
          <UploadSection onDocumentUpload={handleDocumentUpload} />
        )}
        
        {currentSection === 'analysis' && sopDocument && (
          <AnalysisSection 
            document={sopDocument}
            isAnalyzing={isAnalyzing}
            onStartAnalysis={handleAnalysisStart}
            onViewReport={handleViewReport}
            hasReport={!!complianceReport}
          />
        )}
        
        {currentSection === 'report' && complianceReport && (
          <ReportSection 
            report={complianceReport}
            onEditSOP={handleEditSOP}
            onBackToUpload={handleBackToUpload}
          />
        )}
        
        {currentSection === 'editor' && sopDocument && (
          <EditorSection 
            document={sopDocument}
            report={complianceReport}
            onSave={(updatedDoc) => {
              console.log('Saving updated document:', updatedDoc.name)
              setSOPDocument(updatedDoc)
            }}
            onBackToReport={() => setCurrentSection('report')}
          />
        )}
      </main>
      
      <Toaster theme="dark" />
    </div>
  )
}

export default App